<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <title>A.B.O.R.S. - Home</title>
        <link href="topbar.css" rel="stylesheet" type="text/css" />
        <link rel="icon" type="image/png"
        href="https://vignette.wikia.nocookie.net/wingsoffirefanon/images/6/6a/Le-lenny-face.png/revision/latest?cb=20180129214237" />
    </head>
    <body>
        <?php
        $page = htmlspecialchars($_GET["p"]);
        ?>
        <ul>
	        <li><a href="http://abors.epizy.com/" id="selected">Home</a></li>
	        <li><a href="schoolstoof">School Stoof</a></li>
	        <li><a href="videostoof">Video Stoof</a></li>
	        <li><a href="freestoof">Free Stoof</a></li>
        </ul>
    </body>
</html>